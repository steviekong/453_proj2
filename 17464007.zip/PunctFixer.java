package com.gradescope.punctfixer; // DO NOT MODIFY PACKAGE NAME OR CLASS NAME

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class PunctFixer {

  private HashSet<String> dictionary;
	
  // Load dictionary.txt on class load
	public PunctFixer(String dictionaryFilename) {
    this.dictionary = loadDictionary(dictionaryFilename);
	}
	
  // Read the dictionary file
	public HashSet<String> loadDictionary(String filename) {
		HashSet<String> dictionary = new HashSet<String>();
		try {
			Scanner scanner = new Scanner(new File(filename));
			while (scanner.hasNextLine()) {
				String line = scanner.nextLine();
				dictionary.add(line.trim());
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return dictionary;
	}
	
	
	/**
   * Implement a dynamic programming algorithm to fix punctuation here.
   * The input will be a string that has had its spaces removed, and may
   * or may not contain words from the dictionary that was loaded.
   *
   * Your job is to detect whether the string is made up of valid words
   * from the dictionary.
   *
   * Use the helper method dict(String w) to check whether a word w is
   * in the dictionary.
   *
   * @s String - The input string
   * @returns - true or false, depending on whether the input string was valid.
	 */
	public boolean fixPunct(String s)
	{
    return false;
	}
	
	/**
	 * Checks if a given String is in the dictionary
	 * Returns true if it is, false otherwise
	 * @param s
	 * @return
	 */
	public boolean dict(String s)
	{
		if(this.dictionary.contains(s)) 
      return true;
    else
		  return false;
	}
	
	/**
   * You can use this method for testing and debugging if you wish.
	 */
	public static void main(String[] args) {
    PunctFixer pf = new PunctFixer("dictionary.txt");
	}

}
