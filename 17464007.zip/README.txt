HW6 Programming Assignment

You may choose to implement this in either Java or Python using the provided stubs.
Inside the code stubs you will find that the code to load the dictionary from the included
dictionary.txt file is already coded, you just need to worry about the fix_punct or fixPunct functions.

You may add any functions you want, but do not change the name or arguments of any of the provided functions.

Do not change the class path or file names (otherwise they won't upload to gradescope).
You will upload either punctfixer.py or PunctFixer.java to Gradescope.

When you upload to gradescope, your code will be run through a series of tests that can be used for debugging.
However, there will be tests not included that will only be run after the submission is due, so make sure
you test edge cases!
