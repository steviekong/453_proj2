class PunctFixer(object):

    def __init__(self, filename):
        self.load_dictionary(filename)

    """
    Helper method to load the dictionary file.
    """
    def load_dictionary(self, filename):
        with open(filename) as handle:
            self.dictionary = set(w.strip() for w in handle)
    
    """   
   * Implement a dynamic programming algorithm to fix punctuation here.
   * The input will be a string that has had its spaces removed, and may
   * or may not contain words from the dictionary that was loaded.
   *
   * Your job is to detect whether the string is made up of valid words
   * from the dictionary.
   *
   * Use the helper method dict(String w) to check whether a word w is
   * in the dictionary.
   *
   * @s String - The input string
   * @returns - true or false, depending on whether the input string was valid.
    """
    def fix_punct(self, string):
        return False


"""
You can use this for debugging if you wish.
"""
if __name__ == "__main__":
    pf = PunctFixer("dictionary.txt")
